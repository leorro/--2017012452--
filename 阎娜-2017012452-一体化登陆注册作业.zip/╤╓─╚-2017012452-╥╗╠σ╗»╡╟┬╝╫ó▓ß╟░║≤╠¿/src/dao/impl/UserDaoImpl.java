package dao.impl;

//实现接口UserDao
import dao.UserDao;
import entity.User;

import javax.swing.text.Document;

public class UserDaoImpl implements UserDao {
    @Override
    public User find(String userName, String userPassword) {
        return null;
    }

    @Override
    public void add(User user) {

    }

    @Override
    public User find(String userName) {
        return null;
    }
}
